import { Events } from 'discord.js';
import { updateStarboardReaction } from '../services/starboardService.js';
import { logger } from '../utils/logger.js';
export default {
  name: Events.MessageReactionAdd,
  async execute(reaction, user, client) {
    try { await updateStarboardReaction(reaction, user, client, true); }
    catch (error) { logger.error('Starboard add reaction handler failed:', error); }
  },
};
