import { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, MessageFlags } from 'discord.js';
import { getStarboardConfig, saveStarboardConfig, buildStarLeaderboard } from '../../services/starboardService.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';

const manageSubcommands = ['setup', 'disable', 'set-channel', 'set-threshold', 'set-emoji', 'self-star'];

export default {
  data: new SlashCommandBuilder()
    .setName('starboard')
    .setDescription('Configure the server starboard and view its leaderboard')
    .setDMPermission(false)
    .addSubcommand(s => s.setName('setup').setDescription('Enable starboard and set its main options')
      .addChannelOption(o => o.setName('channel').setDescription('Channel for featured messages').addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addIntegerOption(o => o.setName('threshold').setDescription('Non-bot stars required (default 3)').setMinValue(1).setMaxValue(100).setRequired(false))
      .addStringOption(o => o.setName('emoji').setDescription('Reaction emoji to track (default ⭐)').setMinLength(1).setMaxLength(32).setRequired(false))
      .addBooleanOption(o => o.setName('self-star').setDescription("Whether the message author's own reaction counts (default false)").setRequired(false)))
    .addSubcommand(s => s.setName('set-channel').setDescription('Change where featured messages are posted')
      .addChannelOption(o => o.setName('channel').setDescription('Starboard channel').addChannelTypes(ChannelType.GuildText).setRequired(true)))
    .addSubcommand(s => s.setName('set-threshold').setDescription('Change how many stars a message needs')
      .addIntegerOption(o => o.setName('amount').setDescription('Required star reactions').setMinValue(1).setMaxValue(100).setRequired(true)))
    .addSubcommand(s => s.setName('set-emoji').setDescription('Change which reaction emoji is counted')
      .addStringOption(o => o.setName('emoji').setDescription('Emoji to track, e.g. ⭐ or 🔥').setMinLength(1).setMaxLength(32).setRequired(true)))
    .addSubcommand(s => s.setName('self-star').setDescription("Choose whether authors can count their own star")
      .addBooleanOption(o => o.setName('enabled').setDescription('True = count author reaction; false = ignore it').setRequired(true)))
    .addSubcommand(s => s.setName('settings').setDescription('View all current starboard settings'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable the starboard'))
    .addSubcommand(s => s.setName('leaderboard').setDescription('Show members with the most featured-message stars')),
  category: 'Community',
  async execute(interaction) {
    await InteractionHelper.safeDefer(interaction, { flags: MessageFlags.Ephemeral });
    const sub = interaction.options.getSubcommand();
    if (manageSubcommands.includes(sub) && !interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      return InteractionHelper.safeEditReply(interaction, 'You need the **Manage Server** permission to change starboard settings.');
    }

    const config = await getStarboardConfig(interaction.client, interaction.guildId);
    if (sub === 'setup') {
      const channel = interaction.options.getChannel('channel');
      const threshold = interaction.options.getInteger('threshold') ?? config.threshold ?? 3;
      const emoji = interaction.options.getString('emoji') ?? config.emoji ?? '⭐';
      const includeSelfStars = interaction.options.getBoolean('self-star') ?? config.includeSelfStars ?? false;
      const me = interaction.guild.members.me;
      const perms = channel.permissionsFor(me);
      if (!perms?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ReadMessageHistory])) {
        return InteractionHelper.safeEditReply(interaction, 'I need View Channel, Send Messages, Embed Links and Read Message History in the starboard channel.');
      }
      await saveStarboardConfig(interaction.client, interaction.guildId, { ...config, enabled: true, channelId: channel.id, threshold, emoji, includeSelfStars });
      return InteractionHelper.safeEditReply(interaction, `⭐ Starboard enabled in ${channel}. A message needs **${threshold} ${emoji}** reactions. Author self-stars are **${includeSelfStars ? 'counted' : 'ignored'}**.`);
    }

    if (sub === 'set-channel') {
      const channel = interaction.options.getChannel('channel');
      const perms = channel.permissionsFor(interaction.guild.members.me);
      if (!perms?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ReadMessageHistory])) {
        return InteractionHelper.safeEditReply(interaction, 'I need View Channel, Send Messages, Embed Links and Read Message History in that channel.');
      }
      await saveStarboardConfig(interaction.client, interaction.guildId, { ...config, channelId: channel.id, enabled: true });
      return InteractionHelper.safeEditReply(interaction, `Starboard channel changed to ${channel}.`);
    }

    if (sub === 'set-threshold') {
      const threshold = interaction.options.getInteger('amount');
      await saveStarboardConfig(interaction.client, interaction.guildId, { ...config, threshold });
      return InteractionHelper.safeEditReply(interaction, `Starboard threshold set to **${threshold} ${config.emoji}**. Existing posts will be re-evaluated when their reactions next change.`);
    }

    if (sub === 'set-emoji') {
      const emoji = interaction.options.getString('emoji').trim();
      await saveStarboardConfig(interaction.client, interaction.guildId, { ...config, emoji });
      return InteractionHelper.safeEditReply(interaction, `Starboard will now count **${emoji}** reactions. Existing posts will update when reactions next change.`);
    }

    if (sub === 'self-star') {
      const includeSelfStars = interaction.options.getBoolean('enabled');
      await saveStarboardConfig(interaction.client, interaction.guildId, { ...config, includeSelfStars });
      return InteractionHelper.safeEditReply(interaction, `Author self-stars are now **${includeSelfStars ? 'enabled' : 'disabled'}**.`);
    }

    if (sub === 'settings') {
      const embed = new EmbedBuilder().setTitle('⭐ Starboard Settings').setColor(0xF1C40F)
        .addFields(
          { name: 'Status', value: config.enabled ? 'Enabled' : 'Disabled', inline: true },
          { name: 'Channel', value: config.channelId ? `<#${config.channelId}>` : 'Not set', inline: true },
          { name: 'Required reactions', value: `${config.threshold} ${config.emoji}`, inline: true },
          { name: "Count author's own star", value: config.includeSelfStars ? 'Yes' : 'No', inline: true },
          { name: 'Featured messages', value: `${Object.keys(config.entries || {}).length}`, inline: true },
        );
      return InteractionHelper.safeEditReply(interaction, { embeds: [embed] });
    }

    if (sub === 'disable') {
      await saveStarboardConfig(interaction.client, interaction.guildId, { ...config, enabled: false });
      return InteractionHelper.safeEditReply(interaction, 'Starboard disabled. Existing featured posts have been left in the channel.');
    }

    const lines = buildStarLeaderboard(config, interaction.guild);
    const embed = new EmbedBuilder().setTitle('⭐ Starboard Leaderboard').setColor(0xF1C40F)
      .setDescription(lines.length ? lines.join('\n') : 'No messages have reached the starboard yet.')
      .setFooter({ text: `Total stars received · ${config.emoji}` });
    return InteractionHelper.safeEditReply(interaction, { embeds: [embed] });
  },
};
