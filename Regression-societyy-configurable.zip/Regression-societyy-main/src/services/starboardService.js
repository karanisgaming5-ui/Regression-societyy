import { EmbedBuilder } from 'discord.js';

const KEY = (guildId) => `starboard:${guildId}`;
const DEFAULTS = { enabled: false, channelId: null, threshold: 3, emoji: '⭐', includeSelfStars: false, entries: {} };

export async function getStarboardConfig(client, guildId) {
  const saved = await client.db.get(KEY(guildId)).catch(() => null);
  return { ...DEFAULTS, ...(saved || {}), entries: { ...(saved?.entries || {}) } };
}

export async function saveStarboardConfig(client, guildId, config) {
  const normalized = { ...DEFAULTS, ...config, entries: { ...(config.entries || {}) } };
  await client.db.set(KEY(guildId), normalized);
  return normalized;
}

export async function updateStarboardReaction(reaction, user, client, added) {
  if (!reaction?.message?.guild || user?.bot) return;
  if (reaction.partial) await reaction.fetch().catch(() => null);
  const source = reaction.message;
  if (!source.guild || source.author?.bot) return;
  const config = await getStarboardConfig(client, source.guild.id);
  if (!config.enabled || !config.channelId || reaction.emoji.name !== config.emoji) return;
  if (source.channelId === config.channelId) return;

  // Exclude the message author's own reaction from the qualifying star count.
  const reactingUsers = await reaction.users.fetch().catch(() => null);
  const count = reactingUsers
    ? reactingUsers.filter((member) => !member.bot && (config.includeSelfStars || member.id !== source.author.id)).size
    : Math.max(0, (reaction.count ?? 0) - (config.includeSelfStars ? 0 : 1));
  const key = source.id;
  const entry = config.entries[key] || { channelId: source.channelId, authorId: source.author.id, starboardMessageId: null, stars: 0 };
  const boardChannel = await source.guild.channels.fetch(config.channelId).catch(() => null);
  if (!boardChannel?.isTextBased() || !boardChannel.messages) return;

  if (count < config.threshold) {
    if (entry.starboardMessageId) {
      const oldPost = await boardChannel.messages.fetch(entry.starboardMessageId).catch(() => null);
      if (oldPost) await oldPost.delete().catch(() => {});
    }
    delete config.entries[key];
    await saveStarboardConfig(client, source.guild.id, config);
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(0xF1C40F)
    .setAuthor({ name: source.author.tag, iconURL: source.author.displayAvatarURL() })
    .setDescription(source.content?.slice(0, 4000) || '*No text content*')
    .addFields(
      { name: 'Source', value: `<#${source.channelId}>`, inline: true },
      { name: 'Stars', value: `${config.emoji} ${count}`, inline: true },
    )
    .setTimestamp(source.createdAt)
    .setFooter({ text: `Message ID: ${source.id}` });
  if (source.url) embed.addFields({ name: 'Jump to message', value: `[Open original](${source.url})` });
  const attachment = source.attachments?.first();
  if (attachment?.contentType?.startsWith('image/')) embed.setImage(attachment.url);

  let boardPost = entry.starboardMessageId
    ? await boardChannel.messages.fetch(entry.starboardMessageId).catch(() => null)
    : null;
  const payload = { content: `${config.emoji} **${count}** · <#${source.channelId}>`, embeds: [embed] };
  entry.stars = count;
  if (boardPost) await boardPost.edit(payload).catch(() => null);
  else {
    boardPost = await boardChannel.send(payload).catch(() => null);
    if (!boardPost) return;
    entry.starboardMessageId = boardPost.id;
  }
  config.entries[key] = entry;
  await saveStarboardConfig(client, source.guild.id, config);
}

export function buildStarLeaderboard(config, guild) {
  const totals = new Map();
  for (const entry of Object.values(config.entries || {})) {
    totals.set(entry.authorId, (totals.get(entry.authorId) || 0) + (entry.stars || 0));
  }
  return [...totals.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10)
    .map(([userId, stars], i) => `${['🥇', '🥈', '🥉'][i] || `**${i + 1}.**`} <@${userId}> — **${stars}** stars`);
}
