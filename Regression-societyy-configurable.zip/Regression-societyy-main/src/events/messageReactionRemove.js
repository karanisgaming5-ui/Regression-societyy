import { Events } from 'discord.js';
import { updateStarboardReaction } from '../services/starboardService.js';
import { logger } from '../utils/logger.js';
export default {
  name: Events.MessageReactionRemove,
  async execute(reaction, user, client) {
    try { await updateStarboardReaction(reaction, user, client, false); }
    catch (error) { logger.error('Starboard remove reaction handler failed:', error); }
  },
};
